package team.woo.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class CalendarDTO {
    private List<String> selectedDates;
    private String scheduleName;
}