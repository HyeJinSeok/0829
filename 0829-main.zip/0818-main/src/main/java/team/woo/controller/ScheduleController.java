package team.woo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import team.woo.algorithm.TaskAllocation;
import team.woo.domain.Schedule;
import team.woo.domain.ScheduleService;
import team.woo.member.Member;
import team.woo.session.SessionManager;

import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDate;

@Controller
public class ScheduleController {

    private final ScheduleService scheduleService;
    private final SessionManager sessionManager;
    private static final Logger logger = LoggerFactory.getLogger(ScheduleController.class);

    public ScheduleController(ScheduleService scheduleService, SessionManager sessionManager) {
        this.scheduleService = scheduleService;
        this.sessionManager = sessionManager;
    }

    @GetMapping("/create")
    public String add() {
        return "create";
    }

    @PostMapping("/create")
    public String addSchedule(
            @RequestParam("name") String name,
            @RequestParam("startTime") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startTime,
            @RequestParam("deadLine") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate deadLine,
            @RequestParam("difficulty") int difficulty,
            @RequestParam("urgency") int urgency,
            @RequestParam("importance") int importance,
            @RequestParam("restTime") String restTime,
            @RequestParam("stress") int stress,
            @RequestParam("preferenceTime") String preferenceTime,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {

        Member loginMember = (Member) sessionManager.getSession(request);


        if (loginMember == null) {
            logger.warn("세션에서 사용자 정보를 가져오지 못함. 비로그인 상태로 처리.");
        } else {
            logger.info("세션에서 사용자 정보 가져옴: 사용자 ID = {}", loginMember.getId());
        }


        Schedule schedule;
        if (loginMember != null) {
            // 로그인된 사용자의 경우
            schedule = new Schedule(name, startTime, deadLine, difficulty, importance, urgency, restTime, preferenceTime, stress, loginMember.getId());
        } else {
            // 비로그인 사용자의 경우
            schedule = new Schedule(name, startTime, deadLine, difficulty, importance, urgency, restTime, preferenceTime, stress);
        }

        Schedule savedSchedule = scheduleService.saveSchedule(schedule, loginMember != null ? loginMember.getId() : null);

        redirectAttributes.addAttribute("id", savedSchedule.getId());
        return "redirect:/result/{id}";  // result 페이지로 이동
    }

    @GetMapping("/result/{id}")
    public String showResult(@PathVariable Long id, Model model, HttpServletRequest request) {
        Schedule schedule = scheduleService.getSchedule(id);
        model.addAttribute("schedule", schedule);

        Member loginMember = (Member) sessionManager.getSession(request);
        model.addAttribute("loginMember", loginMember);

        return "result";
    }

    @GetMapping("/select/{id}")
    public String task(@PathVariable Long id, Model model, HttpServletRequest request) {
        Member loginMember = (Member) sessionManager.getSession(request);

        if (loginMember != null) {
            logger.info("사용자 세션 확인: 사용자 ID = {}", loginMember.getId());
        } else {
            logger.info("비로그인 상태에서 접근: 세션이 없습니다.");
        }

        Schedule schedule = scheduleService.getSchedule(id);
        model.addAttribute("schedule", schedule);
        model.addAttribute("loginMember", loginMember);
        return "select";
    }

    @PostMapping("/select")
    public String selectOption(@RequestParam("option") String option,
                               @RequestParam("id") Long id,
                               HttpServletRequest request,
                               RedirectAttributes redirectAttributes) {

        Schedule schedule = scheduleService.getSchedule(id);
        Member loginMember = (Member) sessionManager.getSession(request);

        int totalScore = TaskAllocation.calculateTotalScore(schedule.getDifficulty(), schedule.getUrgency(), schedule.getImportance(), schedule.getStress());

        LocalDate deadLine = schedule.getDeadLine();
        LocalDate startTime = schedule.getStartTime();
        int availableDays = (int) (deadLine.toEpochDay() - startTime.toEpochDay());
        int adjustDays = TaskAllocation.calculateAdjustDays(availableDays, option);
        double adjustTime = TaskAllocation.calculateAdjustTime(totalScore);

        schedule.setAdjustDays(adjustDays);
        schedule.setAdjustTime(adjustTime);

        if (loginMember != null && schedule.getMember() == null) {
            schedule.setMember(loginMember);
        }

        scheduleService.updateSchedule(schedule);

        redirectAttributes.addAttribute("id", id);
        return "redirect:/result_ts/{id}";
    }
}