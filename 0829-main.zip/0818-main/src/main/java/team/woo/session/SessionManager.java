package team.woo.session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class SessionManager {

    public static final String SESSION_COOKIE_NAME = "mySessionId";
    private Map<String, Object> sessionStore = new ConcurrentHashMap<>();
    private static final Logger logger = LoggerFactory.getLogger(SessionManager.class);

    public void createSession(Object value, HttpServletResponse response) {
        String sessionId = UUID.randomUUID().toString();
        sessionStore.put(sessionId, value);

        // 쿠키 생성
        Cookie mySessionCookie = new Cookie(SESSION_COOKIE_NAME, sessionId);
        mySessionCookie.setHttpOnly(true);
        mySessionCookie.setSecure(false); // HTTPS 환경에서는 true로 설정
        mySessionCookie.setPath("/"); // 어플리케이션 전체에서 접근 가능하도록 설정
        response.addCookie(mySessionCookie);

        logger.info("세션 생성: 세션 ID = {}, 사용자 정보 = {}", sessionId, value);
    }

    public Object getSession(HttpServletRequest request) {
        Cookie sessionCookie = findCookie(request, SESSION_COOKIE_NAME);
        if (sessionCookie == null) {
            logger.warn("세션 쿠키가 존재하지 않습니다.");
            return null;
        }
        Object session = sessionStore.get(sessionCookie.getValue());
        if (session == null) {
            logger.warn("세션 저장소에서 세션을 찾을 수 없습니다. 세션 ID = {}", sessionCookie.getValue());
        } else {
            logger.info("세션을 성공적으로 찾았습니다. 세션 ID = {}", sessionCookie.getValue());
        }
        return session;
    }

    public void expire(HttpServletRequest request) {
        Cookie sessionCookie = findCookie(request, SESSION_COOKIE_NAME);
        if (sessionCookie != null) {
            sessionStore.remove(sessionCookie.getValue());
            logger.info("세션 만료: 세션 ID = {}", sessionCookie.getValue());
        }
    }

    private Cookie findCookie(HttpServletRequest request, String cookieName) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            return null;
        }
        return Arrays.stream(cookies)
                .filter(cookie -> cookie.getName().equals(cookieName))
                .findAny()
                .orElse(null);
    }
}