package team.woo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WooApplicationTests {

    @Test
    void contextLoads() {
    }

}
